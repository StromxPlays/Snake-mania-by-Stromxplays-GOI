# Snake game by StromXPlays GOi
# youtube link: 
import pygame
import random
import os

SCREENWIDTH = 700
SCREENHEIGHT = 500
HIGHSCORE = None

#Initialization
pygame.mixer.init()
pygame.init()


#Colors
white = (255, 255, 255)
red = (255, 0, 0)
black = (0, 0, 0)
snakegreen = (35, 45, 40)

#Game Backgrounds
bg1 = pygame.image.load("Assests/images/bg.jpg")
intro = pygame.image.load("Assests/images/intro.jpg")
outro = pygame.image.load("Assests/images/game_over.jpg")

#Music
pygame.mixer.music.load('Assests/music/bg_music.mp3')
pygame.mixer.music.play(100)
pygame.mixer.music.set_volume(.6)

#Variables For The Game
clock = pygame.time.Clock()
font = pygame.font.SysFont('Harrington', 35)

WINDOW = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
TITLE = pygame.display.set_caption("Snake Mania by StromX")


# Making the main fucntions

def text_screen(text, color, x, y):
   screen_text = font.render(text, True, color)
   WINDOW.blit(screen_text, [x,y])

def plot_snake(WINDOW, color, snake_list, snake_size):
   for x,y in snake_list:
       pygame.draw.rect(WINDOW, color, [x, y, snake_size, snake_size], 2)


def welcome():
    exit_game = False
    while not exit_game:
        WINDOW.blit(intro, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_game = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    pygame.mixer.music.fadeout(200)
                    pygame.mixer.music.load('Assests/music/bg_music.mp3')
                    pygame.mixer.music.play(100)
                    pygame.mixer.music.set_volume(.6)
                    gameLoop()  # Call the gameLoop function here
        pygame.display.update()  # Add this line to update the screen
        clock.tick(60)



def gameLoop():
    # defining the variables
    exit_game = False
    game_over = False  # initialize game_over variable
    snake_x = 45
    snake_y = 55
    velocity_x = 0
    velocity_y = 0
    snake_list = []
    snake_length = 1

    # Highscore Build
    if not os.path.exists("highscore.txt"):
        with open("highscore.txt", "w") as f:
            f.write("0")
    with open("highscore.txt", "r") as f:
        highscore = f.read()

    food_x = random.randint(20, SCREENHEIGHT / 2)
    food_y = random.randint(20, SCREENWIDTH / 2)

    # Game Variables
    score = 0
    init_velocity = 5
    snake_size = 30
    fps = 60
    while not exit_game:
        if game_over:
            with open("highscore.txt", "w") as f:
                f.write(str(highscore))

# GameOverScreen

            WINDOW.blit(outro, (0, 0))
            text_screen("Score: " + str(score), snakegreen, 385, 350)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit_game = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        welcome()
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit_game = True
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RIGHT:
                        velocity_x = init_velocity
                        velocity_y = 0
                    if event.key == pygame.K_LEFT:
                        velocity_x = - init_velocity
                        velocity_y = 0
                    if event.key == pygame.K_UP:
                        velocity_y = - init_velocity
                        velocity_x = 0
                    if event.key == pygame.K_DOWN:
                        velocity_y = init_velocity
                        velocity_x = 0
                    if event.key == pygame.K_q:
                        score += 10
            snake_x = snake_x + velocity_x
            snake_y = snake_y + velocity_y
            if abs(snake_x - food_x) < 12 and abs(snake_y - food_y) < 12:
                score += 10
                food_x = random.randint(20, SCREENWIDTH / 2)
                food_y = random.randint(20, SCREENHEIGHT / 2)
                snake_length += 5
                if score > int(highscore):
                    highscore = score
            WINDOW.blit(bg1, (0, 0))
            text_screen("Score: " + str(score) + "  Highscore: " + str(highscore), snakegreen, 5, 5)
            pygame.draw.rect(WINDOW, red, [food_x, food_y, snake_size, snake_size], 2)
            head = []
            head.append(snake_x)
            head.append(snake_y)
            snake_list.append(head)

            if len(snake_list) > snake_length:
                del snake_list[0]
            if head in snake_list[:-1]:
                game_over = True
                pygame.mixer.music.load('Assests/music/eat.mp3')
                pygame.mixer.music.play(100)
                pygame.mixer_music.set_volume(.6)
            if snake_x<0 or snake_x>SCREENWIDTH or snake_y<0 or snake_y>SCREENHEIGHT:
                game_over = True
                pygame.mixer.music.load('music/bgm2.mp3')
                pygame.mixer.music.play(100)
                pygame.mixer.music.set_volume(.6)
            plot_snake(WINDOW, black, snake_list, snake_size)
        pygame.display.update()
        clock.tick(fps)
    pygame.quit()
    quit()
welcome()    